---------------------------------------------------------------------------------
--
-- bigNumbersDetail.lua
--
---------------------------------------------------------------------------------

local storyboard = require( "storyboard" )
local scene = storyboard.newScene()
local navBarH = navBarH-1 

---------------------------------------------------------------------------------
-- BEGINNING OF YOUR IMPLEMENTATION
---------------------------------------------------------------------------------

--local image, text1, text2, text3, memTimer


local function backBtnRelease()
--	if event.phase == "began" then
		navBarShow( 1 )
		navBar.x = dispW
		
		storyboard.gotoScene( "bigNumbersList", "slideLeft", tt )
		transition.to(navBar, {time=tt, x=0, transition=easing.outQuad })
		
		return true
--	end
end


-- Called when the scene's view does not exist:
function scene:createScene( event )
---------------------------------------------------------------------------------------------------
--setup a detailScreen for the mean2me list items
---------------------------------------------------------------------------------------------------

	local screenGroup = self.view
	local detailData = bigNumberData

    local mean2meDetailScreen = display.newGroup()

	local detailBg = display.newRect(0,0,display.contentWidth,display.contentHeight-display.screenOriginY)
	detailBg:setFillColor(0,0,12)
	mean2meDetailScreen:insert(detailBg)

	local navBarBg = display.newImage(pathBackg .. "navBarEmpty.png")
	mean2meDetailScreen:insert(navBarBg)
	navBarBg.y = math.floor(navBarH/2) + display.screenOriginY


	local detailTitleBg = display.newImage(pathBackg .. "listBg.png" ,  0, navBarH + display.screenOriginY, true) 
	mean2meDetailScreen:insert(detailTitleBg)

	local date = display.newText(detailData.date, 0, 0, native.systemFont, textSize)
	mean2meDetailScreen:insert(date)
	date:setTextColor(100, 200, 250)
	date.x = 260 - math.floor(date.width*0.5)
	date.y = navBarH + math.floor(date.height*1.5) + display.screenOriginY

	local title = display.newText(detailData.title, 0, 0, native.systemFontBold, textSize)
	title:setTextColor(255, 255, 250)
	mean2meDetailScreen:insert(title)
	title.x = math.floor(title.width/2) + 50
	title.y = navBarH + 9 + display.screenOriginY

	local value = display.newText(wert(detailData.value), 0, 0, native.systemFontBold, 22)
	value:setTextColor(255, 255, 250)
	mean2meDetailScreen:insert(value)
	value.x = 317 - math.floor(value.width*0.5)
	value.y = navBarH + 9 + display.screenOriginY

	local detailInfoTop    = navBarH + detailTitleBg.height + 10 + display.screenOriginY
	local detailInfoHeight = 200
	local detailInfoBottom = detailInfoTop + detailInfoHeight
	local detailInfoBg     = display.newRoundedRect (10, detailInfoTop, dispW-20, detailInfoHeight,15)
	detailInfoBg:setFillColor(250,250,200)
	mean2meDetailScreen:insert(detailInfoBg)
	-- mean2meDetailScreen.x = display.contentWidth
	
	local bb=display.newRoundedRect(mean2meDetailScreen,10,detailInfoBottom+20,300,80,15)
	bb:setFillColor( 255,255,255,150)
	bb:setStrokeColor(255,255,255,150)

	backBtn = ui.newButton{ 									--Setup the back button
		default = "widget_ios/button/forwardLarge/default.png", 
		over = "widget_ios/button/forwardLarge/over.png", 
		onRelease = backBtnRelease
	}
	backBtn:setText("Cancel")
--	backBtn.text.size = math.floor(textSize*0.7)
print ("DFGH: ",screenOffsetH, screenOffsetW)
	backBtn.x = dispW - 5 - math.floor(backBtn.width/2) + screenOffsetW
	backBtn.y = math.floor(navBarH/2) + screenOffsetH + display.screenOriginY
	backBtn.alpha = 1
	mean2meDetailScreen:insert(backBtn)

	screenGroup:insert( mean2meDetailScreen )
	print( "\n3: createScene event" )
---------------------------------------------------------------------------------------------------
end


-- Called immediately after scene has moved onscreen:
function scene:enterScene( event )
	
	print( "3: enterScene event" )
	
	-- remove previous scene's view
	storyboard.purgeScene( "mean2meList" )
	
	-- update Lua memory text display
	local showMem = function()
--		image:addEventListener( "touch", image )
--		text3.isVisible = true
--		text2.text = text2.text .. collectgarbage("count")/1000 .. "MB"
--		text2.x = display.contentWidth * 0.5
	end
--	memTimer = timer.performWithDelay( 1000, showMem, 1 )
end


-- Called when scene is about to move offscreen:
function scene:exitScene()
	
	print( "3: exitScene event" )
	
	-- remove touch listener for image
--	image:removeEventListener( "touch", image )
	
	-- cancel timer
--	timer.cancel( memTimer ); memTimer = nil;
	
	-- reset label text
--	text2.text = "MemUsage: "
end


-- Called prior to the removal of scene's "view" (display group)
function scene:destroyScene( event )
	detailData = nil
	print( "((destroying scene 3's view))" )
end

---------------------------------------------------------------------------------
-- END OF YOUR IMPLEMENTATION
---------------------------------------------------------------------------------

-- "createScene" event is dispatched if scene's view does not exist
scene:addEventListener( "createScene", scene )

-- "enterScene" event is dispatched whenever scene transition has finished
scene:addEventListener( "enterScene", scene )

-- "exitScene" event is dispatched before next scene's transition begins
scene:addEventListener( "exitScene", scene )

-- "destroyScene" event is dispatched before view is unloaded, which can be
-- automatically unloaded in low memory situations, or explicitly via a call to
-- storyboard.purgeScene() or storyboard.removeScene().
scene:addEventListener( "destroyScene", scene )

---------------------------------------------------------------------------------

return scene