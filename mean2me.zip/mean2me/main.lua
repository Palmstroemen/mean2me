--
-- Abstract: composer Sample
--
-- Version: 1.0
-- 
-- Sample code is MIT licensed, see http://www.coronalabs.com/links/code/license
-- Copyright (C) 2011 Corona Labs Inc. All Rights Reserved.
--
-- Demonstrates use of the composer API (scene events, transitioning, etc.)
--
print ("")
print ("")
print ("===============================")
print ("== Start Mean2Me")
print ("===============================")
print ("")

-----------------------------------------------------------------------------
-- Roadmap
--
--   numpad 1.0
--   bigNumbersDetail 1.0 (start with Copy from mean2meDetail)
--   bigNumbersListOrganizer 1.0
--   WerbeListe für InAppKäufe
--   Liste Natur (Weltraum, Biologie, ...)
--   Liste Länder der Erde
--   Icon, Logo
-- PRE_RELEASE 1.0
--
--   Webseite
--   InAppKäufe iOS
--   InAppKäufe Android
-- RELEASE 1.0
--
-- Change Icons
-- Setup (Startseite, Farben, ...)
-- RELEASE 1.1
-- Reorder Categories




-- hide device status bar
display.setStatusBar( display.HiddenStatusBar )
tt  = 400 		-- transition time horizontal
ttt = 1200		-- transition time vertical
navBarH = 40
dispW = display.contentWidth
dispH = display.contentHeight
screenOffsetW = dispW -  display.viewableContentWidth 
screenOffsetH = dispH - display.viewableContentHeight
pathIcons = "images/icons/"
pathBackg = "images/backgrounds/"


-- require controller module
local composer   = require "composer"
local widget     = require "widget"
numPadLib 		 = require "numPad"
native	 		 = require "native"
require "supportFunctions"

-- setup some global variables
composer.state = {} 				--for storing global variables

topBoundary = display.screenOriginY + navBarH
bottomBoundary = display.screenOriginY + 0
eingabewert = 1000000000
bigNumbersListShow = "center"

actualScene = "mean2meList"

-- load first scene
--composer.gotoScene( "bigNumbersList", "fade", 400 )
composer.gotoScene( "mean2meList", "fade", 400 )
--composer.gotoScene( "numPad", "fade", 400 )


--
-- Display objects added below will not respond to composer transitions
--



local function mean2meBtnRelease( event )
---------------------------------------------------------------------------------------------------
-- Mean2Me Button
---------------------------------------------------------------------------------------------------
	print( "mean2me button released" )

	actualScene = "mean2meList"
	composer.gotoScene( "mean2meList", "slideLeft", tt  )
	transition.to(backBtn, 		{time=tt, alpha=1 })
	transition.to(mean2meBtn,   {time=tt, alpha=0 })

	delta, velocity = 0, 0 
	return true
end




local function backBtnRelease( event )
---------------------------------------------------------------------------------------------------
-- back (Num) Button
---------------------------------------------------------------------------------------------------
	print( "mean2meListBack button released" )

	bigNumbersListShow = "center"
	actualScene = "bigNumbersList"
	composer.gotoScene( "bigNumbersList", "slideRight", tt  )
	transition.to(backBtn, 		{time=tt, alpha=0 })
	transition.to(mean2meBtn,   {time=tt, alpha=1 })

	delta, velocity = 0, 0
	return true
end





local function numBtnRelease( event )
---------------------------------------------------------------------------------------------------
-- NumButton (above the Number)
---------------------------------------------------------------------------------------------------
	print( "numberButton released" )
	
	composer.state.returnItem = "eingabewert"
	numPad( eingabewert )
	return true
end







---[[
function navBarShow( status )
---------------------------------------------------------------------------------------------------
--Setup the nav bar 
-- status decides if 0 .. mean2me Button is displayed or
--					 1 .. Num Button (backButton) is displayed
---------------------------------------------------------------------------------------------------
	navBar = display.newGroup()
	navBarBg   = display.newImage( pathBackg .. "navBarDisplay.png", 0, 0, true )
	navBar:insert(navBarBg)
	navBarBg.x = math.floor(dispW*0.5)
	navBarH    = navBarBg.height
print ("NavBarHeight: ",navBarH)
	navBarBg.y = math.floor(display.screenOriginY + navBarH*0.5)

	navHeader = display.newText(wert(eingabewert), 0, 0, native.systemFontBold, 24)
	navBar:insert(navHeader)
	navHeader:setTextColor(55, 70, 90)
	navHeader.x = math.floor(dispW*0.5)
	navHeader.y = math.floor(display.screenOriginY + navBarH*0.5)+0

	numBtn = ui.newButton{ 								--Setup the NumberButton
		default = pathBackg .. "numButton.png", 
		over 	= pathBackg .. "numButton.png", 
		onRelease = numBtnRelease
	}
	numBtn.x = 156
	numBtn.y = math.floor(display.screenOriginY + navBarH*0.5)
	numBtn.title = ""
	numBtn.alpha = 1
	navBar:insert(numBtn)

	mean2meBtn = ui.newButton{							--Setup the mean2me button
		default 	= "widget_ios/button/forwardLarge/default.png", 
		over 		= "widget_ios/button/forwardLarge/over.png", 
		onRelease 	= mean2meBtnRelease
	}
	mean2meBtn.x = math.floor(mean2meBtn.width*0.5) + mean2meBtn.width + 140
	mean2meBtn.y = math.floor(display.screenOriginY + navBarH*0.5)
	mean2meBtn:setText("mean2me")
	mean2meBtn.text.size = math.floor(mean2meBtn.text.size*0.7)
	mean2meBtn.alpha = status
	navBar:insert(mean2meBtn)

	backBtn = ui.newButton{ 						--Setup the back on the mean2me page button
		default 	= "widget_ios/button/backSmall/default.png", 
		over 		= "widget_ios/button/backSmall/over.png", 
		onRelease 	= backBtnRelease, 60,30,
	}
	backBtn.x = math.floor(backBtn.width*0.5) + screenOffsetW + 5
	backBtn.y = math.floor(display.screenOriginY + navBarH*0.5) 
	backBtn:setText("Num")
	backBtn.text.size = math.floor(backBtn.text.size*0.7)
	backBtn.alpha = 1-status
	navBar:insert(backBtn)
---------------------------------------------------------------------------------------------------
end

navBarShow( 0 )

composer.state.returnItem = "eingabewert"
numPad( eingabewert )
