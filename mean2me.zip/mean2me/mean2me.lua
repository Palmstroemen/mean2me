-- 
-- Abstract: List View sample app (with items grouped by header titles)
--  
-- Version: 1.0
-- 
-- Sample code is MIT licensed, see http://developer.anscamobile.com/code/license
-- Copyright (C) 2010 ANSCA Inc. All Rights Reserved.
--
-- Demonstrates how to create a list view using the Table View Library.
-- This sample in particular shows how to use the header parameter to
-- organize rows into groups with titles above each group.

--import
local tableView = require("tableView")			--import the table view library
local ui 		= require("ui")					--import the button events library

local data

--local function numBtnRetRelease()
--end
 
-- verstecke den Standard Statusbar am oberen Bildschirmrand (mit Empfangsanzeige, Batterie, ...)	
display.setStatusBar( display.HiddenStatusBar ) 

--initial values
-- displaysize
local dispW = display.contentWidth
local dispH = display.contentHeight
local screenOffsetW = dispW -  display.viewableContentWidth 
local screenOffsetH = dispH - display.viewableContentHeight
local topBoundary = display.screenOriginY + 40
local bottomBoundary = display.screenOriginY + 0
local navBarH = 40

local mean2meList, backBtn, numBtn, mean2meDetailScreenText, numBtnRetRelease

local tt  = 600 
local ttt = 1200


--local background = display.newRect(0, 0, display.contentWidth, display.contentHeight)
--background:setFillColor(77, 77, 77)



--import the Numpad library
--local num = require("numpad")




---------------------------------------------------------------------------------------------------
-- setup some data for the mean2meList
---------------------------------------------------------------------------------------------------
data = {}
for i=1, 8 do
	data[i] = {}
	data[i].title = ""
	data[i].info  = "Angenommen Sie wohnen in einem Land mit 8 Mio. Einwohnern. Wenn Sie nun wissen wollen wie sehr sich die Zahl auf jeden einzelnen von den 8 Mio. auswirkt, dividieren Sie einfach die Zahl durch 8 Mio."
	data[i].wert  = 0.00 + i
	data[i].nom   = 1.0 +2*i
	data[i].denom = 100.00 *i
	data[i].fakt  = data[i].nom/data[i].denom
	data[i].bild  = "Flag_Austria.png"
	data[i].category = "Kategorie"
end

--add some items that have arbitrary categories
data[1].title = "neu"
data[1].category = "Neu"
data[1].bild = "Plus.png"
data[1].wert = 0.0

data[6].title = "Gesamt"
data[6].category = "Österreich"
data[6].fakt = 7.90
data[6].wert = data[6].fakt * tonumber("10.00")

data[7].title = "Steuerzahler"
data[7].category = "Österreich"
data[7].wert = 2.90

data[8].title = "Meine Steuer"
data[8].category = "Österreich"
data[8].bild ="Icon_Person.png"
data[8].wert = 3.20

data[4].title = "Gesamt"
data[4].category = "Deutschland"
data[4].wert = 4.90
data[4].bild = "Flag_Germany.png"

data[5].title = "Steuerzahler"
data[5].category = "Deutschland"
data[5].bild = "Flag_Germany.png"
data[5].wert = 3.80

data[2].title = "Gesamt"
data[2].category = "EU"
data[2].bild = "Flag_EU.png"
data[2].wert = 2.70

data[3].title = "Steuerzahler"
data[3].category = "EU"
data[3].bild = "Flag_EU.png"
data[3].wert = 4.70


--specify the order for the groups in each category
local headers = { "EU", "Österreich", "Deutschland","Neu" }





---------------------------------------------------------------------------------------------------
-- Setup some data for the bigNumbersList
---------------------------------------------------------------------------------------------------
bigNumbers = {}
for i=1,100 do
	bigNumbers[i] = {}
	bigNumbers[i].title = "Event ".. i
	bigNumbers[i].value = i*1000000
	bigNumbers[i].currency = "€"
	bigNumbers[i].date = 2012-i
	bigNumbers[i].info = "Eine Erklärung zu diesem Ereignis, kann durchaus über mehrere Zeilen gehen. Und so weiter und so fort. Hauptsache dieser Text ist eimal so richtig lang."
	bigNumbers[i].reference = "Ein oder mehrere Links"
end

local currencyOrder = {"€", "$"}













local function numBtnRelease( event )
---------------------------------------------------------------------------------------------------
-- Titelleiste Textfeld
---------------------------------------------------------------------------------------------------
	print("number button released")
--	transition.to(mean2meList,    {time=ttt, y=dispH,   transition=easing.outExpo })
--	transition.to(bigNumbersList, {time=ttt, y=dispH,   transition=easing.outExpo })
	transition.to(numpadScreen,   {time=ttt, y=0,       transition=easing.outExpo })
    transition.to(mean2meBtn,     {time=ttt, alpha = 0, transition=easing.outExpo })
	transition.to(mean2meBackBtn, {time=ttt, alpha = 0, transition=easing.outExpo })

	delta, velocity = 0, 0
end


local function numBtnRetRelease( event)
---------------------------------------------------------------------------------------------------
-- Numpad Button Return
---------------------------------------------------------------------------------------------------
    print("number button RETURN released")
    transition.to(mean2meList,        {time=ttt, y=navBarH, transition=easing.outExpo })
    transition.to(bigNumbersList,     {time=ttt, y=navBarH, transition=easing.outExpo })
    transition.to(numpadScreen,       {time=ttt, y= -dispH+100+navBarH, transition=easing.outExpo })
    if mean2meList.x > 0 then
    	transition.to(mean2meBtn,     {time=ttt, alpha = 1, transition=easing.outExpo })
    else
    	transition.to(mean2meBackBtn, {time=ttt, alpha = 1, transition=easing.outExpo })
    end
end



local function bigNumbersListButtonRelease( event )
---------------------------------------------------------------------------------------------------
--setup functions to execute on touch of the BigNumbersList view items
---------------------------------------------------------------------------------------------------
	self = event.target
	local id = self.id
	local data = bigNumbers[id]
    print("BigNumbers ID: ", id)
	
--	mean2meDetailScreenText.text = "[".. self.id.."] "..data.title
--	mean2meDetailScreenNum.text  = tostring(data.nom)
--	mean2meDetailScreenDenum.text= tostring(data.denom)
--	mean2meDetailScreenFakt.text = tostring(data.fakt)
--	mean2meDetailScreenId = id
			
--	transition.to(mean2meList, {time=600, x=-display.contentWidth, transition=easing.inOutExpo })
--	transition.to(navBar, {time=600, x=-display.contentWidth, transition=easing.inOutExpo })
--	transition.to(mean2meDetailScreen, {time=600, x=0, transition=easing.inOutExpo })
--	transition.to(backBtn, {time=400, x=math.floor(backBtn.width/2) + screenOffsetW/2, transition=easing.outExpo })
--  transition.to(mean2meBackBtn, {time=400, alpha=0})
--	transition.to(backBtn, {time=400, alpha=1 })
--	transition.to(numBtn,  {time=400, alpha=0 })
	
	delta, velocity = 0, 0
end





local function mean2meBtnRelease( event )
---------------------------------------------------------------------------------------------------
-- Mean2Me Button
---------------------------------------------------------------------------------------------------
	print("mean2me button released")
	transition.to(bigNumbersList, {time=tt, x=-dispW, transition=easing.outExpo })
	transition.to(mean2meList,    {time=tt, x=0,      transition=easing.outExpo })
	transition.to(mean2meBackBtn, {time=tt, alpha=1 })
	transition.to(mean2meBtn,     {time=tt, alpha=0 })

	delta, velocity = 0, 0
    
end



local function mean2meBackBtnRelease( event )
---------------------------------------------------------------------------------------------------
-- Mean2Me Page Back Button
---------------------------------------------------------------------------------------------------
	print("mean2me page Back button released")
	transition.to(mean2meList,    {time=tt, x=dispW, transition=easing.outExpo })
	transition.to(bigNumbersList, {time=tt, x=0,     transition=easing.outExpo })
	transition.to(mean2meBtn,     {time=tt, alpha=1 })
	transition.to(mean2meBackBtn, {time=tt, alpha=0 })

	delta, velocity = 0, 0
    
end



local function mean2meListItemRelease( event )
---------------------------------------------------------------------------------------------------
--setup functions to execute on touch of the list view items
---------------------------------------------------------------------------------------------------
	self = event.target
    id = self.id
    print("Mean2Me List item released: ",id)
    print(data[id].bild)
	local data = data[id]
 	
    print(detailIcon)
    detailIcon:removeSelf()
    detailIcon          = display.newImage(data.bild, 10, navBarH + detailCatBtn.height+7, true)
    mean2meDetailScreen:insert(detailIcon)
     
	detailCatBtn:setText(data.category)
    detailCatBtn.text.size = 16
    detailCatBtn.text.x = -detailCatBtn.width/2 + detailCatBtn.text.width/2 + 12

	mean2meDetailScreenText.text = data.title
	mean2meDetailScreenText.x = math.floor(mean2meDetailScreenText.width/2) + 72
	
	mean2meDetailScreenNum.text  = tostring(data.nom)
	mean2meDetailScreenDenum.text= tostring(data.denom)
	mean2meDetailScreenFakt.text = tostring(data.fakt)
	mean2meDetailScreenId = id
			
	transition.to(navBar,              {time=tt, x=-dispW, transition=easing.inOutExpo })
	transition.to(mean2meList,         {time=tt, x=-dispW, transition=easing.inOutExpo })
	transition.to(mean2meDetailScreen, {time=tt, x=0,      transition=easing.inOutExpo })
	transition.to(backBtn,             {time=tt, x=math.floor(backBtn.width/2) + screenOffsetW/2, transition=easing.outExpo })
    transition.to(mean2meBackBtn,      {time=tt, alpha=0})
	transition.to(backBtn,             {time=tt, alpha=1 })
	transition.to(numBtn,              {time=tt, alpha=0 })
	
	delta, velocity = 0, 0
end




local function backBtnRelease( event )
---------------------------------------------------------------------------------------------------
-- Mean2Me Detail View Button Back
---------------------------------------------------------------------------------------------------
	print("Mean2Me Detail back button released")
    
	data[id].fakt = data[id].nom/data[id].denom
	data[id].wert = data[id].fakt

	transition.to(mean2meList,           {time=tt, x=0,     transition=easing.outExpo })
	transition.to(navBar,                {time=tt, x=0,     transition=easing.outExpo })
	transition.to(mean2meDetailScreen,   {time=tt, x=dispW, transition=easing.outExpo })
    transition.to(mean2meBackBtn,        {time=tt, alpha=1})
	transition.to(backBtn,               {time=tt, alpha=0 })
	transition.to(numBtn,                {time=tt, alpha=1 })

	delta, velocity = 0, 0
    
end











bigNumbersList = tableView.newList{
---------------------------------------------------------------------------------------------------
-- Create the bigNumbersList with header titles
---------------------------------------------------------------------------------------------------
	data=bigNumbers, 
	default="listBg.png",
	over="listBgOver.png", 
	onRelease=bigNumbersListButtonRelease,
	top=topBoundary,
	bottom=bottomBoundary,
	cat="currency",
	order=currencyOrder,
	categoryBackground="catBg.png",
	backgroundColor={ 0, 5, 0 },
	callback = function(item) 
			local datum = display.newText(item.date, 0, 0, native.systemFont, 11)
			datum:setTextColor(100, 200, 250)
			datum.x = math.floor(datum.width/2) + 12
			datum.y = 5 
			return datum
		end,
	callback2 = function(item) 
			local title = display.newText(item.title, 0, 0, native.systemFontBold, 11)
			title:setTextColor(255, 255, 250)
			title.x = math.floor(title.width/2) + 50
			title.y = 5 
			return title
        end,
	callback3 = function(item) 
			local title = display.newText(item.value, 0, 0, native.systemFont, 16)
			title:setTextColor(255, 255, 250)
			title.x = math.floor(title.width/2) + 240
			title.y = 15 
			return title
		end
    }

bigNumbersList.x = 0  --display.contentWidth
bigNumbersList.y = navBarH --display.contentHeight
---------------------------------------------------------------------------------------------------





local function _mean2meList()
mean2meList = tableView.newList{
---------------------------------------------------------------------------------------------------
-- Create the Mean2Me list with header titles
---------------------------------------------------------------------------------------------------
	data=data, 
	default="listItemBg.png",
	over="listBgOver.png",
	onRelease=mean2meListItemRelease,
	top=topBoundary,
	bottom=bottomBoundary,
	cat="category",
	order=headers,
	categoryBackground="catBg.png",
	backgroundColor={ 0, 0, 10 },
	callback = function(item) 
			local t = display.newText(item.title, 0, 0, native.systemFontBold, textSize)
			t:setTextColor(200, 200, 200)
			t.x = math.floor(t.width/2) + 72
			t.y = 26 
			return t
		end,
	callback2 = function(item) 
			local w = display.newText(item.wert, 0, 0, native.systemFont, textSize)
			w:setTextColor(255, 125, 50)
			w.x = math.floor(w.width/2) + 250
			w.y = 26 
			return w
		end,
	callback3 = function(item) 
			local b = display.newImage(item.bild, 0, 0, true)
			b.x = math.floor(b.width/2) + 10
			b.y = 25
			return b
		end
    }

mean2meList.x = display.contentWidth
mean2meList.y = navBarH
---------------------------------------------------------------------------------------------------
end
_mean2meList()




---------------------------------------------------------------------------------------------------
-- Setup the numpadScreen
--
--	Ccccc	Return		
--	7	8	9	Mio
--	4	5	6	Mrd
--	1	2	3	Bil
--	,	0  000	Brd
--	
---------------------------------------------------------------------------------------------------
numpadScreen = display.newGroup()

local numpadBg = display.newRect(0,0,dispW,dispH-display.screenOriginY-100)
numpadBg:setFillColor(50,20,15)
numpadScreen:insert(numpadBg)

local numpadScreenText = display.newText("Das Numpad", 0, 0, native.systemFontBold, 24)
numpadScreenText:setTextColor(140, 100, 90)
numpadScreen:insert(numpadScreenText)
numpadScreenText.x = math.floor(display.contentWidth/2)
numpadScreenText.y = math.floor(display.contentHeight/4)

numpadScreen.y = -dispH
numpadScreen.x = 0

numBtnRet = ui.newButton{ 
	default = "buttonBlue.png", 
	over = "buttonBlueOver.png", 
	onRelease = numBtnRetRelease
}
numBtnRet.x = 160
numBtnRet.y = 320
--numBtnRet:setLabel("Hallo")
numBtnRet.alpha = 0.5
numpadScreen:insert(numBtnRet)
---------------------------------------------------------------------------------------------------







navBar = display.newGroup()
---------------------------------------------------------------------------------------------------
--Setup the nav bar 
---------------------------------------------------------------------------------------------------
navBarBg   = display.newImage("navBarDisplay.png", 0, 0, true)
navBar:insert(navBarBg)
navBarBg.x = math.floor(dispW*0.5)
navBarH    = navBarBg.height
print ("NavBarHeight: ",navBarH)
navBarBg.y = math.floor(display.screenOriginY + navBarH*0.5)

local navHeader = display.newText("34.00 Mrd", 0, 0, native.systemFontBold, 24)
navBar:insert(navHeader)
navHeader:setTextColor(55, 70, 90)
navHeader.x = math.floor(dispW*0.5)
navHeader.y = math.floor(navBarH/2)+0

numBtn = ui.newButton{ 								--Setup the NumberButton
	default = "numButton.png", 
	over = "numButton.png", 
	onRelease = numBtnRelease
}
numBtn.x = 156
numBtn.y = math.floor(navBarH/2)
numBtn.title = ""
numBtn.alpha = 1
navBar:insert(numBtn)

mean2meBtn = ui.newButton{							--Setup the mean2me button
	default = "buttonToRight.png", 
	over = "buttonToRightOver.png", 
	onRelease = mean2meBtnRelease
}
mean2meBtn.x = math.floor(mean2meBtn.width*0.5) + mean2meBtn.width + 140
mean2meBtn.y = math.floor(navBarH/2)
mean2meBtn:setText("mean2me")
mean2meBtn.text.size = 14
mean2meBtn.text.y = mean2meBtn.text.y-2
--mean2meBtn.text:setTextColor(190, 200, 230)
navBar:insert(mean2meBtn)

mean2meBackBtn = ui.newButton{ 						--Setup the back on the mean2me page button
	default = "buttonToLeftSmall.png", 
	over = "buttonToLeftSmallOver.png", 
	onRelease = mean2meBackBtnRelease
}
mean2meBackBtn.x = math.floor(mean2meBackBtn.width/2) + screenOffsetW
mean2meBackBtn.y = math.floor(navBarH/2) 
mean2meBackBtn:setText("Back")
mean2meBackBtn.text.size = 12
mean2meBackBtn.alpha = 0
navBar:insert(mean2meBackBtn)
---------------------------------------------------------------------------------------------------





function inputCatRelease()
---------------------------------------------------------------------------------------------------
-- Wenn der Kategoriebutton gedrückt wird
---------------------------------------------------------------------------------------------------
	print("Category Button released")
end




---------------------------------------------------------------------------------------------------
--setup a detailScreen for the mean2me list items
---------------------------------------------------------------------------------------------------
mean2meDetailScreen = display.newGroup()

local detailBg = display.newRect(0,0,display.contentWidth,display.contentHeight-display.screenOriginY)
detailBg:setFillColor(0,0,12)
mean2meDetailScreen:insert(detailBg)

local navBarBg = display.newImage("navBarEmpty.png")
mean2meDetailScreen:insert(navBarBg)
navBarBg.y = math.floor(navBarH/2)


detailCatBtn = ui.newButton{							--Setup the category button
	default = "catBg.png", 
	over    = "catBg.png", 
	onRelease = inputCatRelease
}
detailCatBtn:setText("Kategorie")
detailCatBtn.text.size = 12
detailCatBtn.text.x = -math.floor(detailCatBtn.width/2) + 55
detailCatBtn.x = math.floor(detailCatBtn.width*0.5)
detailCatBtn.y = math.floor(detailCatBtn.height*0.5) + navBarH
mean2meDetailScreen:insert(detailCatBtn)

detailIcon = display.newImage("Icon_Person.png", 10, navBarH + detailCatBtn.height+7, true)
mean2meDetailScreen:insert(detailIcon)

local detailTitleBg = display.newImage("listItemBg.png" ,  0, navBarH + detailCatBtn.height   , true) 
mean2meDetailScreen:insert(detailTitleBg)

mean2meDetailScreenText = display.newText("Titel ", 0, 0, native.systemFontBold, textSize)
mean2meDetailScreenText:setTextColor(200, 200, 200)
mean2meDetailScreen:insert(mean2meDetailScreenText)
mean2meDetailScreenText.x = math.floor(mean2meDetailScreenText.width/2) + 72
mean2meDetailScreenText.y = navBarH + detailCatBtn.height + 26

local detailInfoTop    = navBarH + detailCatBtn.height + detailTitleBg.height + 10
local detailInfoHeight = 200
local detailInfoBottom = detailInfoTop + detailInfoHeight
local detailInfoBg     = display.newRect (10, detailInfoTop, dispW-20, detailInfoHeight)
detailInfoBg:setFillColor(250,250,200)
mean2meDetailScreen:insert(detailInfoBg)
-- mean2meDetailScreen.x = display.contentWidth

mean2meDetailScreenNum = display.newText("1.00", 0, 0)
mean2meDetailScreenNum:setTextColor(200, 200, 200)
mean2meDetailScreen:insert(mean2meDetailScreenNum)
mean2meDetailScreenNum.x = math.floor(display.contentWidth/2)
mean2meDetailScreenNum.y = detailInfoBottom + 40

mean2meDetailScreenDenum = display.newText("1.00", 0, 0)
mean2meDetailScreenDenum:setTextColor(200, 200, 200)
mean2meDetailScreen:insert(mean2meDetailScreenDenum)
mean2meDetailScreenDenum.x = math.floor(display.contentWidth/2)
mean2meDetailScreenDenum.y = detailInfoBottom + 80

mean2meDetailScreenFakt = display.newText("1.00", 0, 0)
mean2meDetailScreenFakt:setTextColor(100, 200, 200)
mean2meDetailScreenFakt.size = 10
mean2meDetailScreen:insert(mean2meDetailScreenFakt)
mean2meDetailScreenFakt.x = math.floor(display.contentWidth/2)
mean2meDetailScreenFakt.y = detailInfoBottom + 120

mean2meDetailScreen.y = 0
mean2meDetailScreen.x = dispW

backBtn = ui.newButton{ 									--Setup the back button
	default = "buttonToLeftSmall.png", 
	over = "buttonToLeftSmallOver.png", 
	onRelease = backBtnRelease
}
backBtn:setText("Back")
backBtn.text.size = 12
backBtn.x = math.floor(backBtn.width/2) + screenOffsetW
backBtn.y = math.floor(navBarH/2)
backBtn.alpha = 0
mean2meDetailScreen:insert(backBtn)
---------------------------------------------------------------------------------------------------








