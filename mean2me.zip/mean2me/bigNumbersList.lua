---------------------------------------------------------------------------------
--
-- bigNumbersList.lua
--
---------------------------------------------------------------------------------
 
local storyboard = require( "storyboard" )
local scene 	= storyboard.newScene()
local tableView = require("tableView7")			--import the table view library
local ui 		= require("ui")					--import the button events library
local db        = require("bigNumbersDB")		--import the Database
local bigNumbersListMax = 120
local bigNumbersListMin = 80


---------------------------------------------------------------------------------
-- BEGINNING OF YOUR IMPLEMENTATION
---------------------------------------------------------------------------------

local image, text1, text2, text3, memTimer
--local currencyOrder = {"€", "$"}
local currencyOrder = {"...", "$", "€", "... "}















-- Touch event listener for background image
local function onSceneTouch( self, event )
	if event.phase == "began" then
		storyboard.gotoScene( "mean2meList", "slideLeft", tt  )
		return true
	end
end






local function bigNumbersListButtonRelease( event )
---------------------------------------------------------------------------------------------------
--setup functions to execute on touch of the list view items
---------------------------------------------------------------------------------------------------
	self = event.target
    id = self.id
    print("bigNumbersList item released: ",id,bigNumbers[id].date)
    
    if bigNumbers[id].currency == "... " then										
		bigNumbersListMax = math.floor(bigNumbersListMin*1.1)
		bigNumbersListMin = math.floor(bigNumbersListMin*0.8)
		storyboard.gotoScene( "Intermediate", "crossFade", 1 )
		print("Untergrenze: ",bigNumbersListMin,"   Obergrenze: ",bigNumbersListMax)
		
	else if bigNumbers[id].currency == "..."	then
		bigNumbersListMin = math.floor(bigNumbersListMax*0.9)
		bigNumbersListMax = math.floor(bigNumbersListMax*1.25)
		storyboard.gotoScene( "Intermediate", "crossFade", 1 )
		print("Untergrenze: ",bigNumbersListMin,"   Obergrenze: ",bigNumbersListMax)
		end
	end    

	if bigNumbers[id].date == 1 then
	else 
		bigNumberData = bigNumbers[id]
		storyboard.gotoScene ("bigNumbersDetail", "slideRight", tt)
		transition.to(navBar, {time=tt, x=dispW, transition=easing.outQuad})
	end
	return true
end





-- Called when the scene's view does not exist:
function scene:createScene( event )
---------------------------------------------------------------------------------------------------
-- Create the bigNumbersList
---------------------------------------------------------------------------------------------------
	local screenGroup = self.view

	local i, z
	local infoLine = {}
	
	currencyOrder = {"...", "$", "€", "... "}
	bigNumbers = db.readBigNumbersDB(eingabewert, bigNumbersListMin,bigNumbersListMax)

	-- insert current entry
	if #bigNumbers > 2 then								-- catch zero entries
		i = #bigNumbers-1
		while i>2 and bigNumbers[i].value < eingabewert do
			bigNumbers[i+1] = bigNumbers[i]
			i=i-1
		end
		bigNumbers[i+1] = bigNumbers[i] 
		bigNumbers[i] = {}
	else
		bigNumbers = {}
		for i = 1,3 do
			bigNumbers[i] = {}
			bigNumbers[i].date = 1
			bigNumbers[i].value = 0
		end
		bigNumbers[2].date = 0
		i = 2
	end
	
	local newIndex = i
	bigNumbers[newIndex].date  		= 0
	bigNumbers[newIndex].title 		= "neuer Wert"
	bigNumbers[newIndex].value 		= eingabewert
	bigNumbers[newIndex].info  		= "Sie können Ihren Wert in die Liste eintragen."
	bigNumbers[newIndex].currency 	= "€"
	bigNumbers[newIndex].icon  		= "Plus.png"
			
	-- overwrite first entry
	bigNumbers[1].currency 	= "..." 
	bigNumbers[1].title 	= "mehr ..." 
	bigNumbers[1].info 		= ""
	bigNumbers[1].date 		= 1
	bigNumbers[1].icon  	= "Plus.png"

	-- overwrite last entry
	bigNumbers[#bigNumbers].currency 	= "... " 
	bigNumbers[#bigNumbers].title 		= "mehr ..." 
	bigNumbers[#bigNumbers].info 		= ""
	bigNumbers[#bigNumbers].date 		= 1
	bigNumbers[#bigNumbers].icon  		= "Plus.png"
	
	local bigNumbersList = tableView.newList{
		data=bigNumbers, 
		default = pathBackg .. "listBg.png",
		over    = pathBackg .. "listBgOver.png", 
		onRelease=bigNumbersListButtonRelease,
		top		= topBoundary,
		bottom	= bottomBoundary,
		cat		= nil,  --"currency",
		order	= "", --currencyOrder,
		categoryBackground = pathBackg .. "catBg.png",
		backgroundColor = { 0, 5, 0 },
		centerItem = newIndex,
		callback = function(item) 
				if item.currency=="..." or item.currency=="... " then
					local b = display.newImage(pathBackg .. "listBg.png", 0, 0, true)
					b.x = math.floor(b.width*0.5)
					b.y = math.floor(b.height*0.5)
					return b
				else	-- für den aktuellen Eintrag missbraucht für Hintergrund --------------
					if item.date == 0 then
						local b = display.newImage(pathBackg .. "listBgOver.png", 0, 0, true)
						b.x = math.floor(b.width*0.5)
						b.y = math.floor(b.height*0.5)
						return b
					else					-- datum -----------------------------------------------
						local datum = display.newText(item.date, 0, 0, native.systemFont, textSize)
						datum:setTextColor(80, 150, 180)
						datum.x = 260 - math.floor(datum.width*0.5)
						datum.y = math.floor(datum.height*1.5)
						return datum
					end
				end
			end,
		callback2 = function(item) 			-- wert ---------------------------------------------
				local value = display.newText(wert(item.value), 0, 0, native.systemFontBold, 22)
				if item.currency=="..." or item.currency=="... " then
					value:setTextColor(255, 255, 250, 0)
				else
					value:setTextColor(255, 255, 250)
				end
				value.x = 317 - math.floor(value.width*0.5)
				value.y = math.floor(value.height*0.5) 
				return value
    	    end,
		callback3 = function(item) 			-- titel --------------------------------------------
				local title = display.newText(item.title, 0, 0, native.systemFontBold, textSize)
				if item.currency=="..." or item.currency=="... " then -- bei WeiterTasten -------
					title:setTextColor(255, 255, 250, 150)
					title.x = math.floor(dispW*0.5)
					title.y = 20
				else						
					title:setTextColor(255, 255, 250)
					title.x = math.floor(title.width*0.5) + 50
					title.y = math.floor(title.height*0.5) 
				end
				return title
    	    end,
		callback4 = function(item) 			-- Prozentwert --------------------------------------
				local prozentWert = math.round((item.value/eingabewert)*100).."%"
				local prozent = display.newText(prozentWert, 0, 0, native.systemFont, textSize)
				if item.currency=="..." then
					local prozentWert = bigNumbersListMin.."%"
					prozent:setTextColor(200, 140, 50, 200)
				end
				if item.currency=="... " then
					local prozentWert = bigNumbersListMax.."%"
					prozent:setTextColor(200, 140, 50, 200)
				else
					prozent:setTextColor(200, 140, 50)
				end
				prozent.x = 317 - math.floor(prozent.width*0.5)
				prozent.y = math.floor(prozent.height*1.5) 
				return prozent
    	    end,
		callback5 = function(item) 			-- erste Infozeile ----------------------------------
				infoLine=firstLine(item.info,170)
	
				local info = display.newText(infoLine[1], 0, 0, native.systemFont, 12)
				info:setTextColor(115, 115, 110)
				info.x = 50 + math.floor(info.width*0.5)
				info.y = 29 
				return info
			end,
		callback6 = function(item) 			-- zweite Infozeile ---------------------------------
				local info2 = display.newText(infoLine[2], 0, 0, native.systemFont, 12)
				info2:setTextColor(115, 115, 110)
				info2.x = 50 + math.floor(info2.width*0.5)
				info2.y = 41 
				return info2
			end,
		callback7 = function(item) 			-- Icon --------------------------------------------	
				local bild = pathIcons .. item.icon
				local icon = display.newImageRect(bild, 44, 44, true)
				icon.x = 3 + math.floor(icon.width*0.5)
				icon.y = 3 + math.floor(icon.height*0.5) 
				return icon
			end
    }

--	bigNumbersList.x = 0  --display.contentWidth
--	bigNumbersList.y = navBarH --display.contentHeight
---------------------------------------------------------------------------------------------------
--]]
	infoLine = nil
	screenGroup:insert( bigNumbersList )
	tableView.moveList(bigNumbersListShow)
	print( "\n1: createScene event")
end


-- Called immediately after scene has moved onscreen:
function scene:enterScene( event )
	
	print( "1: enterScene event" )
	
	-- remove previous scene's view
	storyboard.purgeScene( "mean2meList" )	
	storyboard.purgeScene( "Intermediate" )
	storyboard.purgeScene( "bigNumbersDetail" )
end


-- Called when scene is about to move offscreen:
function scene:exitScene( event )
	
	print( "1: exitScene event" )
end


-- Called prior to the removal of scene's "view" (display group)
function scene:destroyScene( event )
	
	bigNumberData = nil
	print( "((destroying bigNumbersList view))" )
end

---------------------------------------------------------------------------------
-- END OF YOUR IMPLEMENTATION
---------------------------------------------------------------------------------

-- "createScene" event is dispatched if scene's view does not exist
scene:addEventListener( "createScene", scene )

-- "enterScene" event is dispatched whenever scene transition has finished
scene:addEventListener( "enterScene", scene )

-- "exitScene" event is dispatched before next scene's transition begins
scene:addEventListener( "exitScene", scene )

-- "destroyScene" event is dispatched before view is unloaded, which can be
-- automatically unloaded in low memory situations, or explicitly via a call to
-- storyboard.purgeScene() or storyboard.removeScene().
scene:addEventListener( "destroyScene", scene )

---------------------------------------------------------------------------------

return scene