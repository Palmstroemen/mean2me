---------------------------------------------------------------------------------
--
-- mean2meDetail.lua
--
---------------------------------------------------------------------------------

local storyboard = require( "storyboard" )
local scene 	 = storyboard.newScene()
local navBarH 	 = navBarH-1 
local buttonBar  = require( "cancelOkButtons" )
local db		 = require( "mean2MeDB" )
local widget 	 = require "widget"
widget.setTheme( "theme_ios" )

---------------------------------------------------------------------------------
-- BEGINNING OF YOUR IMPLEMENTATION
---------------------------------------------------------------------------------
local mean2meDetailScreen
local picker
local newCatField
local newCategory = ""
local titleField
local categoryExit = 0






local function backBtnRelease()
-- der Cancel-Button ----------------------------------------------------------------------------------
	storyboard.gotoScene( "mean2meList", "slideRight", tt )
	transition.to(navBar, {time=tt, x=0, transition=easing.outQuad })
	return true
end



local function okBtnRelease()
-- der OK-Button ----------------------------------------------------------------------------------
	print("aktualisiere:",detailData.id)
	db.updateMean2MeData(detailData)
	storyboard.gotoScene( "mean2meList", "slideRight", tt )
	transition.to(navBar, {time=tt, x=0, transition=easing.outQuad })
	return true
end



local function submBtnRelease()
-- der Submit-Button ------------------------------------------------------------------------------
	local i
print("====================")
	for i = 1,#categories do
		print(categories[i])
	end
print("====================")
--	storyboard.gotoScene( "mean2meList", "slideRight", tt )
--	transition.to(navBar, {time=tt, x=0, transition=easing.outQuad })
	return true
end



local function onAskDelete( event )
-- Hilfsfunktion für den Lösch-Button -------------------------------------------------------------
    if "clicked" == event.action then
        local i = event.index
        if 1 == i then
			db.deleteMean2MeData(detailData)
		
			storyboard.gotoScene( "mean2meList", "slideRight", tt )
			transition.to(navBar, {time=tt, x=0, transition=easing.outQuad })
        end
    end
end


local function delBtnRelease()
-- Der Lösch-Button -------------------------------------------------------------------------------
	local alertText = "Sind Sie sicher, dass Sie diesen Eintrag löschen wollen? Dadurch werden die Datan unwiederbringlich gelöscht und die einzige Möglichkeit die Daten wieder zu bekommen besteht darin, diese wieder mühsam einzutippen, was mindestens 5 Minuten Ihrer wertvollen Zeit in Anspruch nimmt. Andererseits benötigt auch das Lesen dieses Textes ungebührlich viel Zeit. Also hören Sie schon auf zu lesen, und löschen Sie endlich die Daten!"
	local alert = native.showAlert( "Löschen?", alertText, { "JA", "Nein" }, onAskDelete )		
	return true
end




--infoBox 

local function infoBoxInputListener( event )
-- der Info-Text ----------------------------------------------------------------------------------
   	if event.phase == "began" then
   	-- user begins editing textBox
    	print( event.text )
		if newCatField then newCatField:removeSelf(); newCatField = "" end

    elseif event.phase == "ended" then
--	    detailData.info = event.text
--	    print( detailData.info )
    	-- do something with textBox's text

	elseif event.phase == "editing" then
	    detailData.info = event.text

    end
end



function showInfoBox()
-- Displays native UI InfoBox
	if not infoBox then
		infoBox = native.newTextBox( 10, 161 + display.screenOriginY, dispW-20, 200 )
		infoBox.text = detailData.info
		infoBox:addEventListener( "userInput", infoBoxInputListener )
		infoBox.isEditable = true
	end
end




function hideInfoBox()

	if infoBox then	
		infoBox:removeSelf()
		infoBox=nil
	end

end



local function newCatEnd()
	transition.to(protector, {time=tt, alpha=0, transition=easing.linear})
	if newCatField then 
print("NewCatEnd",#newCatField)
		native.setKeyboardFocus(nil)
		newCatField:removeSelf()
		newCatField = nil
	end
	categoryExit = 1
end		




local function newCatEingabe( event )
    if event.phase == "began" then
        -- user begins editing textField

print ("newCatEingabe began")
    elseif event.phase == "ended" then
        -- textField/Box loses focus
print ("newCatEingabe ended")
		
		newCatEnd()

    elseif event.phase == "submitted" then
        -- do something with defaulField's text
print ("newCatEingabe submitted", newCategory, "--")
		if not (newCategory == "") and not (newCategory == "Neu") then
			categories[#categories] = newCategory
			categories[#categories + 1] = "Neu"
			detailData.category = newCategory
		    category.text = detailData.category
			category.x = math.floor(category.width/2) + 72
--			newCategory = ""
			categoryExit = 1
		end
--		if newCatField then newCatField:removeSelf(); newCatField = "" end
--		if newCategory == "" then else editCategory() end
--		transition.to(pickerWheelGroup, {time=tt, x=320, transition=easing.outQuad })		
		transition.to(protector, {time=tt, alpha=0, transition=easing.linear})
		transition.to(pickerWheelGroup, {time=tt, alpha=0, transition=easing.outQuad })		
		showInfoBox()
		
    elseif event.phase == "editing" then
		newCategory = event.text
print ("newCatEingabe editing", newCategory)
    end
end




local function newCatCancel( event )
print( "newCategory cancel",event.phase )
	if event.phase == "began" then
print( "newCategory cancel" )
		transition.to(protector, {time=tt, alpha=0, transition=easing.linear})
		if newCatField then 
			newCatField:removeSelf()
			newCatField = nil
		end
		categoryExit = 0
	end
	return true
end





function newCatStart()
	if not newCatField then
		protector = display.newRect(0, display.screenOriginY, 320, 640)
		protector:setFillColor(0,0,0,100)
		protector:addEventListener( "touch", newCatCancel )

		newCategory = ""
		newCatField = native.newTextField( 25, navBarH + display.screenOriginY + 208, 176, 28)
		newCatField.text = ""
		newCatField.font = native.newFont( native.systemFont, 20)

		newCatField.userInput = newCatEingabe
		newCatField:addEventListener( "userInput", newCatEingabe )
		native.setKeyboardFocus( newCatField )
		
	end
end




local function doneBtnRelease()
-- Picker Wheel Done Button -----------------------------------------------------------------------

	detailData.category = picker:getValues()[1].value

	if detailData.category == "Neu" then
		if categoryExit == 0 then
			newCatStart()
		else
			categoryExit = 0
			detailData.category = newCategory
		end
	end
	
	if not(detailData.category == "Neu") then
		newCategory = ""
	    category.text = detailData.category
		category.x = math.floor(category.width/2) + 72
		newCatEnd()
		transition.to(pickerWheelGroup, {time=tt, alpha=0, transition=easing.outQuad })		
		showInfoBox()
	end

end





local function catCancel(event)
	if event.phase == "began" then
		transition.to(pickerWheelGroup, {time=tt, alpha=0, transition=easing.outQuad })		
		showInfoBox()
	end
	return true
end





local function editCategory( event )
-- Das Categorie Eingabefeld wurde geclickt---------------------------------------------------------
	if "began" == event.phase and infoBox then
		pickerWheelGroup = display.newGroup()
		pickerWheelGroup.x = 320
		
		protect = display.newRect(0, 0, 320, 640)
		protect.y = display.screenOriginY
		protect:setFillColor(0,0,0,100)
		protect:addEventListener( "touch", catCancel )
		pickerWheelGroup:insert(protect)
		
		-- Picker Wheel
		local column = {}
		local wheelIndex = table.indexOf(categories, detailData.category)
		column[1] = categories
		column[1].alignment = "left"
		column[1].width = 190
		column[1].startIndex = wheelIndex
		
print ("AAA")		
		picker = widget.newPickerWheel{
		    id="myPicker",
		    font="Helvetica",
		    fontSize = 20,
		    top=150 + display.screenOriginY,
		    columnColor = {100,200,255,255},
		    columns=column
		    }

		pickerWheelGroup:insert( picker )
		hideInfoBox()
		categoryExit = 0
		
		-- OK Button
		local doneBtn = ui.newButton{ 									--Setup the Delete button
			default = "widget_ios/button/blue1Large/default.png", 
			over 	= "widget_ios/button/blue1Large/over.png", 
			onRelease = doneBtnRelease
		}
		doneBtn:setText("OK")
		doneBtn.text.size = math.floor(doneBtn.text.size * 0.6)
		doneBtn.x = dispW - math.floor(doneBtn.width * 0.5) + screenOffsetW - 20
		doneBtn.y = navBarH + display.screenOriginY + 222
		pickerWheelGroup:insert(doneBtn)

		transition.to(pickerWheelGroup, {time=0, x=0, transition=easing.outQuad })		
		transition.to(pickerWheelGroup, {time=0, alpha=0, transition=easing.outQuad })		
		transition.to(pickerWheelGroup, {time=tt, alpha=1, transition=easing.outQuad })		
--		transition.to(pickerWheelGroup, {time=tt, x=0, transition=easing.outQuad })		
		
	end
end





local function textEingabe( event )
    if event.phase == "began" then
print ("titleField began")
        -- user begins editing textField

    elseif event.phase == "ended" then
print ("titleField ended")
        -- textField/Box loses focus
		if titleField then titleField:removeSelf(); titleField=nil end

    elseif event.phase == "ended" or event.phase == "submitted" then
print ("titleField ended or submitted")
        -- do something with defaulField's text

        title.text = detailData.title
		title.x = math.floor(title.width/2) + 72
		if titleField then native.setKeyboardFocus(nil); titleField:removeSelf(); titleField=nil end
		
    elseif event.phase == "editing" then
		detailData.title = event.text

    end
end





local function editTitle( event )
-- Das Titel Eingabefeld ----------------------------------------------------------------------------
	if "began" == event.phase then
		titleField = native.newTextField( 67, navBarH + 11, 176, 28)
		titleField.text = detailData.title
		titleField.font = native.newFont( native.systemFontBold, textSize)
--		titleField.setBackgroundColor(0,0,0)

		titleField.userInput = textEingabe
		titleField:addEventListener( "userInput", textEingabe )
		
		native.setKeyboardFocus( titleField )
	end
end





function scene:createScene( event )
-- Called when the scene's view does not exist:
---------------------------------------------------------------------------------------------------
--setup a detailScreen for the mean2me list items
---------------------------------------------------------------------------------------------------
	local screenGroup = self.view

    mean2meDetailScreen = display.newGroup()

	local detailBg = display.newRect(0, display.screenOriginY, display.contentWidth, display.contentHeight - display.screenOriginY )
	detailBg:setFillColor(5, 0, 40)
	mean2meDetailScreen:insert(detailBg)

	-- Navbar -------------------------------------------------------------------------------------
	local navBarBg = display.newImage("navBarEmpty.png")
	mean2meDetailScreen:insert(navBarBg)
	navBarBg.y = math.floor(navBarH/2) + display.screenOriginY

	backBtn = ui.newButton{ 									--Setup the back button
		default = "widget_ios/button/backSmall/default.png", 
		over 	= "widget_ios/button/backSmall/over.png", 
		onRelease = backBtnRelease
	}
	backBtn:setText("cancel")
	backBtn.text.size = math.floor(backBtn.text.size*0.6)
	backBtn.x = math.floor(backBtn.width*0.5) + screenOffsetW + 5
	backBtn.y = math.floor(navBarH*0.5) + display.screenOriginY
	backBtn.alpha = 1
	mean2meDetailScreen:insert(backBtn)

	okBtn = ui.newButton{ 										--Setup the OK button
		default = "widget_ios/button/blue1Large/default.png", 
		over 	= "widget_ios/button/blue1Large/over.png", 
		onRelease = okBtnRelease
	}
	okBtn:setText("OK")
	okBtn.text.size = math.floor(okBtn.text.size)
	okBtn.x = math.floor(okBtn.width*0.5) + screenOffsetW + backBtn.width + 2
	okBtn.y = math.floor(navBarH*0.5) + display.screenOriginY 
	okBtn.alpha = 1
	mean2meDetailScreen:insert(okBtn)

	submBtn = ui.newButton{ 									--Setup the Delete button
		default = "widget_ios/button/blue2Large/default.png", 
		over 	= "widget_ios/button/blue2Large/over.png", 
		onRelease = submBtnRelease
	}
	submBtn:setText("submit")
	submBtn.text.size = math.floor(submBtn.text.size * 0.6)
	submBtn.x = dispW - math.floor(submBtn.width * 0.5) + screenOffsetW - 72
	submBtn.y = math.floor(navBarH*0.5) + display.screenOriginY 
	mean2meDetailScreen:insert(submBtn)

	delBtn = ui.newButton{ 										--Setup the Delete button
		default = "widget_ios/button/redSmall/default.png", 
		over 	= "widget_ios/button/redSmall/over.png", 
		onRelease = delBtnRelease
	}
	delBtn:setText("delete")
	delBtn.text.size = math.floor(okBtn.text.size * 0.6)
	delBtn.x = dispW - math.floor(delBtn.width * 0.5) + screenOffsetW - 6
	delBtn.y = math.floor(navBarH*0.5) + display.screenOriginY 
	delBtn.alpha = 0.9
	mean2meDetailScreen:insert(delBtn)

	local navBarH = navBarH + display.screenOriginY

--	local detailTitleBg = display.newImage("listItemBg.png" ,  0, navBarH, true) 
--	mean2meDetailScreen:insert(detailTitleBg)

	-- Title Background
	local bt=display.newRoundedRect(mean2meDetailScreen,60,navBarH + 5,190,40,10)
	bt:setFillColor( 180,255,255,40)
    bt:addEventListener( "touch", editTitle )
    mean2meDetailScreen:insert(bt)    

	-- Title Text
	title = display.newText( detailData.title, 0, 0, native.systemFontBold, textSize)
	title:setTextColor(250, 250, 250)
	mean2meDetailScreen:insert(title)
	title.x = math.floor(title.width/2) + 72
	title.y = navBarH + 25

	-- Category Background
	local bc=display.newRoundedRect(mean2meDetailScreen,60,navBarH + 55,190,40,10)
	bc:setFillColor( 180,255,255,40)
    bc:addEventListener( "touch", editCategory )
    mean2meDetailScreen:insert(bc)

	-- Category Text
 	category = display.newText(detailData.category, 0, 0, native.systemFont, textSize)
	category:setTextColor(250, 250, 250)
	mean2meDetailScreen:insert(category)
	category.x = math.floor(category.width/2) + 72
	category.y = navBarH + 75

	-- Icon
	if detailData.category == "Neu" then
		detailData.icon = "Icon-mdpi.png"
	end
	local icon = display.newImageRect(detailData.icon, 54, 54, true)
	mean2meDetailScreen:insert(icon)
	icon.x = 30
	icon.y = navBarH + 75

	local detailInfoTop    = navBarH + 110
	local detailInfoHeight = 222
	local detailInfoBottom = detailInfoTop + detailInfoHeight
	local detailInfoBg     = display.newRoundedRect (10, detailInfoTop, dispW-20, detailInfoHeight, 1)
	detailInfoBg:setFillColor(250,250,250)
	mean2meDetailScreen:insert(detailInfoBg)

	-- Info Background
	local bi=display.newRect(mean2meDetailScreen,0,150 + display.screenOriginY, 320, 222)
	bi:setFillColor( 155,155,155,255)
    mean2meDetailScreen:insert(bi)    

	local bb=display.newRoundedRect(mean2meDetailScreen,10,detailInfoBottom+15,300,80, 15)
	bb:setFillColor( 180,255,255,40)
    mean2meDetailScreen:insert(bb)

	mean2meDetailScreenNum = display.newText(wert(detailData.num), 0, 0, native.systemFontBold, textSize)
	mean2meDetailScreenNum:setTextColor(250, 250, 200)
	mean2meDetailScreen:insert(mean2meDetailScreenNum)
	mean2meDetailScreenNum.x = math.floor(display.contentWidth/2)
	mean2meDetailScreenNum.y = detailInfoBottom + 35
	line = display.newLine(20, detailInfoBottom + 55, 300, detailInfoBottom + 55)
	line:setColor(0,0,0)
	mean2meDetailScreen:insert(line)

	mean2meDetailScreenDenum = display.newText(wert(detailData.denum), 0, 0, native.systemFontBold, textSize)
	mean2meDetailScreenDenum:setTextColor(200, 200, 250)
	mean2meDetailScreen:insert(mean2meDetailScreenDenum)
	mean2meDetailScreenDenum.x = math.floor(display.contentWidth/2)
	mean2meDetailScreenDenum.y = detailInfoBottom + 75

	screenGroup:insert( mean2meDetailScreen )
	print( "\n3: createScene event" )
---------------------------------------------------------------------------------------------------
end


function scene:enterScene( event )
-- Called immediately after scene has moved onscreen:
	
	print( "3: enterScene event" )
	showInfoBox()	
	-- remove previous scene's view
	storyboard.purgeScene( "mean2meList" )
	
end


function scene:exitScene()
-- Called when scene is about to move offscreen:
	if infoBox then infoBox:removeSelf(); infoBox = nil end
	if titleField then titleField:removeSelf(); titleField = nil end
	if newCatField then newCatField:removeSelf(); newCatField = nil end
	if pickerWheelGroup then pickerWheelGroup = nil end
	if picker then picker = nil end
	print( "3: exitScene event" )
	
end


-- Called prior to the removal of scene's "view" (display group)
function scene:destroyScene( event )
	detailData = nil
	print( "((destroying scene 3's view))" )
end

---------------------------------------------------------------------------------
-- END OF YOUR IMPLEMENTATION
---------------------------------------------------------------------------------

-- "createScene" event is dispatched if scene's view does not exist
scene:addEventListener( "createScene", scene )

-- "enterScene" event is dispatched whenever scene transition has finished
scene:addEventListener( "enterScene", scene )

-- "exitScene" event is dispatched before next scene's transition begins
scene:addEventListener( "exitScene", scene )

-- "destroyScene" event is dispatched before view is unloaded, which can be
-- automatically unloaded in low memory situations, or explicitly via a call to
-- storyboard.purgeScene() or storyboard.removeScene().
scene:addEventListener( "destroyScene", scene )

---------------------------------------------------------------------------------

return scene