---------------------------------------------------------------------------------------------------
-- Text supportive functions to format text in certain ways.
---------------------------------------------------------------------------------------------------




wertName = {"","Tsd","Mio","Mrd","Bio","Brd","Trl","Trd","Qio","Qrd"}





function wert(x)
---------------------------------------------------------------------------------------------------
-- Rechnet den Eingangswert x in einen leicht lesbaren Text um
--      70 000 000 -->  70 Mio
-- 700 000 000 000 --> 700 Mrd
---------------------------------------------------------------------------------------------------
	local i=1
	local y=x
	if y then
		while y>=1000 do
			y=y*0.001
			i=i+1
		end
		if y>=100 then
			y=math.round(y,0)
		elseif y>=10 then
			y=math.round(y*10,1)*0.1
		else
			y=math.round(y*100,2)*0.01
		end
		return y.." "..wertName[i]
	else
		return ""
	end
end



function firstLine(text, width) 
---------------------------------------------------------------------------------------------------
-- Bestimmt aus einem langen String die ersten Wörter so dass der gesamte
-- String nicht länger als <width> wird.
---------------------------------------------------------------------------------------------------
	local t = text 
	local s1, s2 = "", ""
	local l 
	local p, pAlt
	p = string.find(t," ",1)
	if p and p<20 then
		s1 = string.sub(t,19,p)
		local a = display.newText(s1,0, -100, native.systemFont, 12)	-- -20, damit's nicht sichtbar ist!!
		while a.width < width and p do
			pAlt = p
			p = string.find(t," ",p+1)
			s1 = string.sub(t,1,p)
			a = display.newText(s1,0, -100, native.systemFont, 12)
		end
		s1 = string.sub(t,1,pAlt)
		l = pAlt+1
		if l<string.len(t) then
			p = pAlt+19
			s2 = string.sub(t,l,l+1)
			a = display.newText(s2,0, -100, native.systemFont, 12)
			local w = width - 10
			while a.width < w and p do
				pAlt = p
				p = string.find(t," ",p+1)
				s2 = string.sub(t,l,p)
				a = display.newText(s2,0, -100, native.systemFont, 12)
			end	
			s2 = string.sub(t,l,pAlt) .. " ..."
		end
		a = nil
	else
		s1 = string.sub(t,1,20)
		s2 = string.sub(t,21,40)
	end
	return {s1,s2}
end




