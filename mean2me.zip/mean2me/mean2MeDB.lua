---------------------------------------------------------------------------------------------------
-- Modul für die mean2me Datenbank		V0.1
-- Oliver Rafelsberger
---------------------------------------------------------------------------------------------------
module(..., package.seeall)
 
require "sqlite3"

print ("SQLite Version:",sqlite3.version())



---------------------------------------------------------------------------------------------------
-- setup some data for the mean2meList
---------------------------------------------------------------------------------------------------
data = {}
for i=1, 8 do
	data[i] = {}
	data[i].id    = 1
	data[i].title = ""
	data[i].info  = "Angenommen Sie wohnen in einem Land mit 8 Mio. Einwohnern. Wenn Sie nun wissen wollen wie sehr sich die Zahl auf jeden einzelnen von den 8 Mio. auswirkt, dividieren Sie einfach die Zahl durch 8 Mio."
	data[i].num   = 1.0
	data[i].denum = 1.00
	data[i].fakt  = data[i].num/data[i].denum
	data[i].wert  = data[i].fakt * eingabewert
	data[i].icon  = "Flag_Austria.png"
	data[i].category 	= "Kategorie"
	data[i].reference	= "www"
end

--add some items that have arbitrary categories
data[1].category = "Neu"
data[1].title = "neu"
data[1].icon = "Plus.png"

data[6].category = "Österreich"
data[6].title = "Gesamt"
data[6].num  = 1.0
data[6].denum= 8000000

data[7].category = "Österreich"
data[7].title = "Steuerzahler"
data[7].num  = 1.0
data[7].denum= 3500000

data[8].category = "Österreich"
data[8].title = "Meine Steuer"
data[8].icon ="Icon_Person.png"
data[8].num  = 1500
data[8].denum= 16000000000


data[4].category = "Deutschland"
data[4].title = "Gesamt"
data[4].icon = "Flag_Germany.png"
data[4].num  = 1.0
data[4].denum= 160000000

data[5].category = "Deutschland"
data[5].title = "Steuerzahler"
data[5].icon = "Flag_Germany.png"
data[5].num  = 1.0
data[5].denum= 80000000

data[2].category = "EU"
data[2].title = "Gesamt"
data[2].icon = "Flag_EU.png"
data[2].num  = 1.0
data[2].denum= 700000000

data[3].category = "EU"
data[3].title = "Steuerzahler"
data[3].icon = "Flag_EU.png"
data[3].num  = 1.0
data[3].denum= 350000000

for i=1, 8 do
	data[i].fakt  = data[i].num/data[i].denum
end



local db




local function openDB()
	local path = system.pathForFile( "mean2me.db", system.DocumentsDirectory ) 
	db = sqlite3.open( path )
end




local function closeDB()
    if db and db:isopen() then
        db:close()
    end
end





---[[
local function onSystemEvent( event )
    if event.type == "applicationExit" then
        closeDB()
    end
end
Runtime:addEventListener( "system", onSystemEvent )
--]]




function addMean2MeData(dd)
---------------------------------------------------------------------------------------------------
-- fügt in die Mean2Me Datenbank einen neuen Datensatz ein.
---------------------------------------------------------------------------------------------------
	local insertQuery
	if dd.id == 1 then
		insertQuery = [[INSERT INTO mean2meDB VALUES (NULL, ]] ..
				[[']] ..dd.title 		.. [[', ]] ..
				[[']] ..dd.category  	.. [[', ]] ..
				[[']] ..dd.icon 	 	.. [[', ]] ..
						dd.num      	.. [[, ]] ..
						dd.denum     	.. [[, ]] ..
				[[']] ..dd.info      	.. [[', ]] ..
				[[']] ..dd.reference 	.. [[' ]] ..
				[[);]]
		print ( "Generiere neue Daten ", db:exec( insertQuery ))
	end	
end





function updateMean2MeData(dd)
---------------------------------------------------------------------------------------------------
-- updatet einen Datensatz
---------------------------------------------------------------------------------------------------
	if dd.id > 1 then
		db:exec( [[UPDATE mean2meDB SET title  	= ']]  .. dd.title 		.. [[' WHERE id = ]] .. dd.id .. [[;]])
		db:exec( [[UPDATE mean2meDB SET category= ']]  .. dd.category 	.. [[' WHERE id = ]] .. dd.id .. [[;]])
		db:exec( [[UPDATE mean2meDB SET icon  	= ']]  .. dd.icon 		.. [[' WHERE id = ]] .. dd.id .. [[;]])
		db:exec( [[UPDATE mean2meDB SET num  	=  ]]  .. dd.num 		.. [[  WHERE id = ]] .. dd.id .. [[;]])
		db:exec( [[UPDATE mean2meDB SET denum   =  ]]  .. dd.denum 		.. [[  WHERE id = ]] .. dd.id .. [[;]])
		db:exec( [[UPDATE mean2meDB SET info  	= ']]  .. dd.info 		.. [[' WHERE id = ]] .. dd.id .. [[;]])
		db:exec( [[UPDATE mean2meDB SET reference=']]  .. dd.reference 		.. [[' WHERE id = ]] .. dd.id .. [[;]])
	else
		addMean2MeData(dd)
	end
end





function deleteMean2MeData(dd)
---------------------------------------------------------------------------------------------------
-- löscht einen Datensatz aus der Mean2Me Datenbank
---------------------------------------------------------------------------------------------------
	if dd.id > 1 then
		local deleteQuery = [[DELETE FROM mean2meDB WHERE id = ]] .. dd.id .. [[;]] 
		print ("Lösche Daten ",dd.id, db:exec( deleteQuery ))
	end

end





local function fillMean2MeDatabase()
---------------------------------------------------------------------------------------------------
-- füllt die Mean2Me Datenbank mit Defaultwerten.
---------------------------------------------------------------------------------------------------
    local i
	for i=1,#data do
		local dd = data[i]
		addMean2MeData(dd)
	end
end






local function createMean2MeDB()
---------------------------------------------------------------------------------------------------
-- erzeugt eine neue Datenbank
---------------------------------------------------------------------------------------------------
	local i, rows

	local tablesetup = [[CREATE TABLE IF NOT EXISTS mean2meDB 
						(
						id INTEGER PRIMARY KEY autoincrement, 
						title 		TEXT, 
						category 	TEXT, 
						icon 		TEXT, 
						num 		INTEGER, 
						denum 		INTEGER, 
						info 		TEXT, 
						reference 	TEXT
						);]]
	print("Hallo::::::")
	print("SetupTable mean2meDB:", db:exec( tablesetup ))
--addBigNumbersData()

	-- check if there are already rows in the database
	for row in db:nrows("SELECT * FROM mean2meDB") do
		rows = row.id
	end
	print( "Datenbank Länge: ", rows )

	-- Fill in some data, if no data already exist
	if rows then
		print ("Daten bereits vorhanden")
	else
		fillMean2MeDatabase()
	end
end





local function deleteMean2MeDB()
---------------------------------------------------------------------------------------------------
-- löscht die Mean2Me Tabelle
---------------------------------------------------------------------------------------------------
	local tableDelete = [[DROP TABLE mean2MeDB;]]
	print("DeleteTable mean2me:", db:exec( tableDelete ))
end	




local function sortMean2MeDB()
--		local SortValue = [[INSERT INTO bigNumbers VALUES (NULL, 0, Ereignis ]] ..i.. [[', 'Flag_EU.png', ]] .. 2012-i .. [[,]] .. 500000000+i*100000000 .. [[, '€', 'Ein Beschreibungstext zu dem Ereignis.', 'www.google.at'); ]]
--		print ("sortiere Daten ", db:exec( insertQuery))
end





function readMean2MeDB()
---------------------------------------------------------------------------------------------------
-- liest Daten aus der Datenbank aus. <value> muss zwischen unter- und obergrenze liegen.
---------------------------------------------------------------------------------------------------
	local mean2me = {{}}
	for row in db:nrows([[SELECT * FROM mean2meDB ORDER BY denum DESC;]]) do
    	mean2me[#mean2me+1] =
		{
		id			= row.id,
	    title 		= row.title,
    	category 	= row.category,
	    icon  		= row.icon,
    	num  		= row.num,
        denum 		= row.denum,
		info  		= row.info,
		reference	= row.reference,
		fakt	 	= row.num / row.denum
	    }
	end
	
	return mean2me
end


openDB()
--deleteMean2MeDB()
print("Create mean2meDB:",createMean2MeDB())
 

