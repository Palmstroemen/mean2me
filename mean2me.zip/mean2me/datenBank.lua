---------------------------------------------------------------------------------------------------
-- Modul für die Datenbank		V0.1
-- Oliver Rafelsberger
---------------------------------------------------------------------------------------------------
module(..., package.seeall)
 
require "sqlite3"
print ("SQLite Version:",sqlite3.version())



---------------------------------------------------------------------------------------------------
-- Setup some data for the bigNumbersList
---------------------------------------------------------------------------------------------------
bigNumbers = {}
---[[
for i=1,1000 do
	bigNumbers[i] = {}
	bigNumbers[i].listID= 0
	bigNumbers[i].title = "Event ".. i
	bigNumbers[i].icon  = "Flag_EU.png"
	bigNumbers[i].value = 1000*1.02^i
	bigNumbers[i].prozent = 0
	bigNumbers[i].currency = "€"
	bigNumbers[i].date = 2012-i
	bigNumbers[i].info = "Eine Erklärung zu diesem Ereignis, kann durchaus über mehrere Zeilen gehen. Und so weiter und so fort. Hauptsache dieser Text ist eimal so richtig lang."
	bigNumbers[i].reference = "Ein oder mehrere Links"
end
--]]
bigNumbers[700].icon = "Flag_USA.png"
bigNumbers[698].icon = "Flag_USA.png"
bigNumbers[697].icon = "world.png"
bigNumbers[696].icon = "world.png"

local db




local function openDB()
	local path = system.pathForFile( "mean2me.db", system.DocumentsDirectory ) 
	db = sqlite3.open( path )
end



--[[
local function onSystemEvent( event )
    if event.type == “applicationExit” then
        if db and db:isopen() then
            db:close()
        end
    end
end
Runtime:addEventListener( “system”, onSystemEvent )
--]]




local function createBigNumbersDB()
---------------------------------------------------------------------------------------------------
-- erzeugt eine neue Datenbank
---------------------------------------------------------------------------------------------------
	local i, rows

	local tablesetup = [[CREATE TABLE IF NOT EXISTS bigNumbers (id INTEGER PRIMARY KEY autoincrement, listID INTEGER, title TEXT, icon TEXT, date INTEGER, value REAL, currency text, info text, website text);]]
	print("SetupTable:", db:exec( tablesetup ))
--addBigNumbersData()

	-- check if there are already rows in the database
	for row in db:nrows("SELECT * FROM bigNumbers") do
		rows=row.id
	end
	print( "Datenbank Länge: ", rows )

	-- Fill in some data, if no data already exist
	if rows then
		print ("Daten bereits vorhanden")
	else
		addBigNumbersData()
	end
end





local function deleteBigNumbersDB()
	local tableDelete = [[DROP TABLE bigNumbers;]]
	print("DeleteTable:", db:exec( tableDelete ))
end	




local function addBigNumbersData()
    local i
	for i=1,#bigNumbers do
		local insertQuery = [[INSERT INTO bigNumbers VALUES (NULL, ]] .. 
							bigNumbers[i].listID    .. [[, ]] .. 
					[[']] ..bigNumbers[i].title 	.. [[', ]] ..
					[[']] ..bigNumbers[i].icon 	 	.. [[', ]] ..
							bigNumbers[i].date      .. [[, ]] ..
							bigNumbers[i].value     .. [[, ]] ..
					[[']] ..bigNumbers[i].currency  .. [[', ]] ..
					[[']] ..bigNumbers[i].info      .. [[', ]] ..
					[[']] ..bigNumbers[i].reference .. [[']] ..
							[[);]]
		print ("Generiere neue Daten ", db:exec( insertQuery), insertQuery)
	end
end



local function sortBigNumbersDB()
--		local SortValue = [[INSERT INTO bigNumbers VALUES (NULL, 0, Ereignis ]] ..i.. [[', 'Flag_EU.png', ]] .. 2012-i .. [[,]] .. 500000000+i*100000000 .. [[, '€', 'Ein Beschreibungstext zu dem Ereignis.', 'www.google.at'); ]]
--		print ("sortiere Daten ", db:exec( insertQuery))
end





function readBigNumbersDB(wert, untergrenze, obergrenze)
---------------------------------------------------------------------------------------------------
-- liest Daten aus der Datenbank aus. <value> muss zwischen unter- und obergrenze liegen.
---------------------------------------------------------------------------------------------------
	local i = 0
	local ww = wert
	local uu = math.floor(wert*untergrenze/100)
	local oo = math.floor(wert*obergrenze/100)
	local bigNumbers = {}
	local a = anzahl

	for row in db:nrows([[SELECT * FROM bigNumbers WHERE value BETWEEN ]]..uu..[[ AND ]]..oo..[[ ORDER BY value DESC;]]) do
    	bigNumbers[#bigNumbers+1] =
		{
    	date  		= row.date,
	    title 		= row.title,
	    icon  		= row.icon,
        value 		= row.value,
    	currency 	= row.currency,
		info  		= row.info,
		percent 	= 0
	    }
		ww = row.value+0.0001
print("Read Data",row.date,row.title,row.value,row.currency)
	end
	
	return bigNumbers
end


openDB()
--deleteBigNumbersDB()
--createBigNumbersDB()
--deleteMean2MeDB()
--createMean2MeDB

print()
 

