---------------------------------------------------------------------------------
--
-- mean2meList.lua
--
---------------------------------------------------------------------------------
detailData = {}

local storyboard= require( "storyboard" )
local scene 	= storyboard.newScene()
local tableV 	= require( "tableView7" )			--import the table view library
local ui 		= require( "ui" )					--import the button events library
local detail	= require( "mean2meDetail2" )
local db		= require( "mean2MeDB" )

--specify the order for the groups in each category
categories = { "EU", "Österreich", "Deutschland","Eigene","Neu" }

print("====================1")
	for i = 1,#categories do
		print(categories[i])
	end
print("====================")




---------------------------------------------------------------------------------
-- BEGINNING OF YOUR IMPLEMENTATION
---------------------------------------------------------------------------------




local function onSceneTouch( self, event )
---------------------------------------------------------------------------------------------------
-- will performed, when a list item is touched
---------------------------------------------------------------------------------------------------
	if event.phase == "began" then
		storyboard.gotoScene( "mean2meDetail", "slideLeft", tt  )
		return true
	end
end







local function mean2meListItemRelease( event )
---------------------------------------------------------------------------------------------------
--setup functions to execute on touch of the list view items
---------------------------------------------------------------------------------------------------
	self = event.target
    id = self.id
    print("Mean2Me List item released: ",event.phase)
	detailData = {}

	detailData = mean2MeData[id]
	if detailData.id == 1 then
		detailData.icon = "Icon_Person.png"
	end
	transition.to(navBar, {time=tt, x=-dispW, transition=easing.outQuad})
	storyboard.gotoScene( "mean2meDetail", "slideLeft", tt  )	
	return true
end








-- Called when the scene's view does not exist:
function scene:createScene( event )
---------------------------------------------------------------------------------------------------
-- Create the Mean2Me list with header titles
---------------------------------------------------------------------------------------------------
	
local screenGroup = self.view
mean2MeData = db.readMean2MeDB()				-- Daten aus DB einlesen

local i = 2
while i>0 do
-- muss 2 mal gemacht werden, weil der erste Aufruf von tableV.newList die
-- Reihenfolge von <categories> verändert. "Neu" muss aber am Ende stehen.
-- Daher wird A = tableV.newList{} einmal aufgerufen.
-- Dann wird <categories> repariert
-- Dann wird A wieder entfernt
-- und zuletzt nochmals A = tableV.newList{} aufgerufen ... und dann stimmts
	if A then A:removeSelf(); A = nil end
	A = tableV.newList{
		data		= mean2MeData,  
		default		= pathBackg .. "listItemBg.png",
		over		= pathBackg .. "listBgOver.png",
		onRelease	= mean2meListItemRelease,
		top			= topBoundary,
		bottom		= bottomBoundary,
		cat			= "category",
		order		= categories,
		categoryBackground 	= pathBackg .. "catBg.png",
		backgroundColor 	= { 5, 0, 40 },
		callback = function(item) 
				local t = display.newText(item.title, 0, 0, native.systemFontBold, textSize)
				t:setTextColor(200, 200, 200)
				t.x = math.floor(t.width*0.5) + 72
				t.y = 26 
				return t
			end,
		callback2 = function(item) 
				local w = display.newText(wert(eingabewert*item.fakt), 0, 0, native.systemFont, textSize)
				w:setTextColor(255, 125, 50)
				w.x = 319 - math.ceil(w.width*0.5)
				w.y = 26 
				return w
			end,
		callback3 = function(item)
				local bild = pathIcons .. item.icon
				local b = display.newImageRect(bild, 44, 44, true)
				b.x = math.floor(b.width*0.5) + 10
				b.y = 25
				return b
			end,
		callback4 = function(item) 
				local a = display.newText("", 0, 0, native.systemFont, textSize)
				return a 
			end,
		callback5 = function(item) 
				local a = display.newText("", 0, 0, native.systemFont, textSize)
				return a 
			end,
		callback6 = function(item) 
				local a = display.newText("", 0, 0, native.systemFont, textSize)
				return a 
			end,
		callback7 = function(item) 
				local a = display.newText("", 0, 0, native.systemFont, textSize)
				return a 
			end

		}
print("------------",A.default)

	-- categories wieder reparieren. (Wird durch diese Zuweisung verändert)
	if i == 2 then				-- beim 2. Durchlauf nicht mehr, sonst entsteht ein nil
		local j = table.indexOf(categories,"Neu")
		table.remove(categories,j)
		categories[#categories+1] = "Neu" 
	end
	i = i-1
end
screenGroup:insert( A )

end



-- Called immediately after scene has moved onscreen:
function scene:enterScene( event )
	
	print( "2: enterScene event" )
	
	-- remove previous scene's view
	storyboard.purgeScene( "bigNumbersList" )
	storyboard.purgeScene( "mean2meDetail" )	
end


-- Called when scene is about to move offscreen:
function scene:exitScene()
	
	print( "2: exitScene event" )
end


-- Called prior to the removal of scene's "view" (display group)
function scene:destroyScene( event )
	
	print( "((destroying mean2meList view))" )
end

---------------------------------------------------------------------------------
-- END OF YOUR IMPLEMENTATION
---------------------------------------------------------------------------------

-- "createScene" event is dispatched if scene's view does not exist
scene:addEventListener( "createScene", scene )

-- "enterScene" event is dispatched whenever scene transition has finished
scene:addEventListener( "enterScene", scene )

-- "exitScene" event is dispatched before next scene's transition begins
scene:addEventListener( "exitScene", scene )

-- "destroyScene" event is dispatched before view is unloaded, which can be
-- automatically unloaded in low memory situations, or explicitly via a call to
-- storyboard.purgeScene() or storyboard.removeScene().
scene:addEventListener( "destroyScene", scene )

---------------------------------------------------------------------------------

return scene