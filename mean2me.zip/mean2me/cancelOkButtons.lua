---------------------------------------------------------------------------------------------------
-- draws the cancel, OK, Delete, Submit buttons
---------------------------------------------------------------------------------------------------
module(..., package.seeall)



function newButt( height )

	buttonsBg = display.newGroup()
	buttonsBg.y = height
	
--	local buttonsBg = display.newRect(0, height, display.contentWidth, 60)
--	buttonsBg:setFillColor(10,10,40)


	btnSubmit = ui.newButton{ 									--Setup the back button
		default = "buttonBlack2Large.png", 
		over = "buttonBlack2Large.png", 
		onRelease = btnSubmitRelease
	}
	btnSubmit:setText("Submit")
	btnSubmit.text.size = math.floor(btnSubmit.text.size*0.75)
	btnSubmit.x = math.floor(btnSubmit.width*0.5) + screenOffsetW
	btnSubmit.y = math.floor(btnSubmit.height*0.5)
	buttonsBg:insert(btnSubmit)

	btnOk = ui.newButton{ 									--Setup the back button
		default = "buttonBlack2Large.png", 
		over = "buttonBlack2Large.png", 
		onRelease = btnOkRelease
	}
	btnOk:setText("OK")
	btnOk.text.size = math.floor( btnOk.text.size*1.2 )
	btnOk.text.color = {40, 255, 40}
	btnOk.x = math.floor( btnOk.width*0.5 ) + screenOffsetW + 80
	btnOk.y = math.floor( btnOk.height*0.5 )
	buttonsBg:insert( btnOk )

	btnCancel = ui.newButton{ 									--Setup the back button
		default = "buttonBlack2Large.png", 
		over = "buttonBlack2Large.png", 
		onRelease = btnCancelRelease
	}
	btnCancel:setText("cancel")
	btnCancel.text.size = math.floor(btnCancel.text.size*0.75)
	btnCancel.x = math.floor(btnCancel.width*0.5) + screenOffsetW + 160
	btnCancel.y = math.floor(btnCancel.height*0.5)
	buttonsBg:insert(btnCancel)

	btnDelete = ui.newButton{ 									--Setup the back button
		default = "buttonBlack2Large.png", 
		over = "buttonBlack2Large.png", 
		onRelease = btnDeleteRelease
	}
	btnDelete.color = {100,0,0}
	btnDelete:setText("delete")
	btnDelete.text.size = math.floor(btnDelete.text.size*0.75)
	btnDelete.x = math.floor(btnDelete.width*0.5) + screenOffsetW + 240
	btnDelete.y = math.floor(btnDelete.height*0.5)
	buttonsBg:insert(btnDelete)

	return buttonsBg
end
