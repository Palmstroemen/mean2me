----------------------------------------------------------------------------------
--
-- numPad.lua
--
-- displays a numPad to enter numbers.
-- A special "000"-key is provided to easily enter large numbers.
-- 
----------------------------------------------------------------------------------
--module(..., package.seeall)
ui = require("ui")

local numValue
local currentScene


----------------------------------------------------------------------------------
-- 
--	NOTE:
--	
--	Code outside of listener functions (below) will only be executed once,
--	unless storyboard.removeScene() is called.
-- 
---------------------------------------------------------------------------------

local numPadKeys = {
{"7"  ,0, 70}, {"8",80, 70}, {"9",160, 70}, {"AC",240, 70},
{"4"  ,0,130}, {"5",80,130}, {"6",160,130}, {"C", 240,130},
{"1"  ,0,190}, {"2",80,190}, {"3",160,190}, {"cancel",240,190},
{",",0,250}, {"0",80,250}, {"000",160,250}, {"OK",240,250} }


local hideNavBar={}
function hideNavBar:timer()
	transition.to( numNavBar, { time=200, alpha=0 })
end


local function hideNumPad()
	transition.to( pad, { time=ttt, y=-dispH - navBarH + display.screenOriginY, transition=easing.outQuad })
	timer.performWithDelay( ttt, hideNavBar, 1)	
end



local function numBackBtnRelease( event )
	hideNumPad()
end



local function numOkBtnRelease( event )
print ("OK", actualScene)
	local numVal = tonumber( numValue )
	if storyboard.state.returnItem == "eingabewert" then
		eingabewert = numVal
--		navHeader:setText( wert(numVal) )
	elseif storyboard.state.returnItem == "mean2meDetailNum"  then
		detailData.num = numVal
		mean2meDetailScreenNum:setText( wert(numVal) )
	elseif storyboard.state.returnItem == "mean2meDetailDenum" then
		detailData.denum = numVal
		mean2meDetailScreenDenum:setText( wert(numVal) )
	end
print (storyboard.state.returnItem, currentScene)

--	storyboard.purgeScene( currentScene )
	storyboard.reloadScene( currentScene )
	hideNumPad()
	
end



local function catchFalseClicks( event )
	return true
end


local function numKeyRelease( event )
	id = event.target.text.text
print ("Key pressed: ",id)
	if id == "AC" then
		numValue = ""
	elseif id == "C" then
		numValue = "" .. numValue
		if #numValue > 0 then
			numValue = numValue:sub( 1, #numValue-1 )
		end
	elseif id == "," then
		numValue = "" .. numValue
		if not numValue:find( ",", 1 ) then
			numValue = numValue .. id
		end
	
	elseif id == "OK" then
		numOkBtnRelease()
	elseif id == "cancel" then
		numBackBtnRelease()
	else
		numValue = numValue .. id
	end

print ("numText: ",numValue)
	number.text 	 = numValue
	number.x 		 = math.floor( dispW - number.width*0.5) + display.screenOriginX - 2
	numberSmall.text = wert( tonumber( numValue ))

	return true
end


---------------------------------------------------------------------------------
-- BEGINNING OF YOUR IMPLEMENTATION
---------------------------------------------------------------------------------

-- Called when the scene's view does not exist:
function numPad( value )
	currentScene = storyboard.getCurrentSceneName()
print( "numPad", currentScene )
	numValue = value
	numText  = "" .. numValue
	pad = display.newGroup()
	
	backg = display.newRect( display.screenOriginX, navBarH + display.screenOriginY, dispW, dispH )
	backg:setFillColor( 50, 50, 50 )
	
	pad:addEventListener( "touch", catchFalseClicks )
	pad:insert( backg )
	pad.y = -dispH
	

	numberBack = display.newImage( pathBackg .. "secondDisplay.png", 0, 0, true )
	pad:insert( numberBack )
	numberBack.x = math.floor( dispW*0.5 )
	numberBack.y = navBarH + numberBack.height*0.5 - 3 + display.screenOriginY
	
	number = display.newText( numValue, 0, 0, native.systemFont, textSize)
	pad:insert( number )
	number:setTextColor( 55, 70, 90 )
	number.x = math.floor( dispW - number.width*0.5) + display.screenOriginX -2
	number.y = math.floor( display.screenOriginY + navBarH +  number.height*0.5 ) + 5



	numNavBar = display.newGroup()

	numberNavBar = display.newImage( pathBackg .. "navBarDisplay.png", 0, 0, true )
	numNavBar:insert( numberNavBar )
	numberNavBar.x = math.floor( dispW*0.5 )
	numberNavBar.y = math.floor( navBarH*0.5 + display.screenOriginY )

	numberSmall = display.newText( wert(numValue), 0, 0, native.systemFontBold, 24)
	numNavBar:insert( numberSmall )
	numberSmall:setTextColor( 55, 70, 90 )
	numberSmall.x = math.floor(dispW*0.5)
	numberSmall.y = math.floor(display.screenOriginY + navBarH*0.5)+0

	glass = display.newImage( pathBackg .. "numButton.png", 0, 0, true ) 
	glass.x = 156
	glass.y = math.floor(display.screenOriginY + navBarH*0.5)
	numNavBar:insert( glass )

	numBackBtn = ui.newButton{ 									--Setup the back button
		default = "widget_ios/button/blue1Small/default.png", 
		over 	= "widget_ios/button/blue1Small/over.png", 
		onRelease = numBackBtnRelease
	}
	numBackBtn:setText("cancel")
	numBackBtn.text.size = math.floor(numBackBtn.text.size*0.7)
	numBackBtn.x = math.floor(numBackBtn.width*0.5) + screenOffsetW + 5
	numBackBtn.y = math.floor(navBarH*0.5) + display.screenOriginY
	numBackBtn.alpha = 1
--	pad:insert( numBackBtn )
	numNavBar:insert( numBackBtn )

--[[
	numOkBtn = ui.newButton{ 										--Setup the OK button
		default = "widget_ios/button/blue1Small/default.png", 
		over 	= "widget_ios/button/blue1Small/over.png", 
		onRelease = numOkBtnRelease
	}
	numOkBtn:setText("OK")
--	numOkBtn.text.size = math.floor(numOkBtn.text.size)
	numOkBtn.x = dispW - math.floor(numOkBtn.width*0.5) + screenOffsetW
	numOkBtn.y = math.floor(navBarH*0.5) + display.screenOriginY
	numOkBtn.alpha = 1
	numNavBar:insert( numOkBtn )
--]]
	numBack = display.newRect (0,80,320,240)
	numBack:setFillColor(0,0,0)
	pad:insert( numBack )
	numBack = display.newRect (240,80,80,240)
	numBack:setFillColor(80,80,80)
	pad:insert( numBack )
	
	for i = 1, 16 do
		numKey = ui.newButton{ 									--Setup the back button
			default = "images/backgrounds/buttonBlack2Large.png", 
			over 	= "images/backgrounds/buttonBlack2Large.png", 
			onRelease = numKeyRelease
		}
		numKey:setText( numPadKeys[i][1])
--		numKey.text.size = math.floor(numKey.text.size*1)
		numKey.x = numPadKeys[i][2] + 40
		numKey.y = numPadKeys[i][3] + 40
		pad:insert( numKey )		
	end
	transition.to( pad, { time=ttt, y=0, transition=easing.outQuad })
	return true	
end



