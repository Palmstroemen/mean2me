		This flag set is created by Nordic Factory and can be freely used!
---------------------------------------------------------------------------------
Please include a link to www.nordicfactory.com on your page when using our flags.

								Thank you! :-P